from django.http import HttpResponse
from django.shortcuts import render
from django.views import View
from myapp.models import *
from django.core.paginator import Paginator

def index(request):
    return render(request,'home.html')

class BloodBanks(View):
    def get(self,request):
        data=Bloodbank.objects.all()
        mydata = BloodBanks.common(data,request)
        return render(request,'bloodbank.html',{'mydata':mydata})
    def post(self,request):
        city=request.POST['city']
        if city:
            data=Bloodbank.objects.filter(city__exact=city) 
        else:
            data=Bloodbank.objects.all()
        mydata = BloodBanks.common(data,request)  
        return render(request,'bloodbank.html',{'mydata':mydata, 'city': city})
    def common(data,request):
        p = Paginator(data, 5)
        page_number = request.GET.get('page')
        return p.get_page(page_number)   